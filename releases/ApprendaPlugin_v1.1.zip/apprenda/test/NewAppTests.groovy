package com.apprenda.integrations.urbancode.test

class NewAppTests {

}
